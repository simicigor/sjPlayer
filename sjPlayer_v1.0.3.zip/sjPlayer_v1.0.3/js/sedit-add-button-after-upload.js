 jQuery(document).ready(function() {
	
	// console.log("upload popup is visible");
	// //jQuery('.button').after('TEST');

	// $(window).bind('tb_load', function() {
	//     console.log("tb load open");
	// });
 
	
	$(window).bind('tb_show', function() {
	    console.log("tb_show");
	});

             
  });